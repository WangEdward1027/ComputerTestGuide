#include <iostream> 
#include <cstdio>
#include <string>
#include <algorithm>

using namespace std;

bool GetNextPermutation(string &str){
    int n = str.size();
    int index = n - 2;
    while(index >= 0 && str[index] >= str[index + 1]){
          index--;
    }
    if(index < 0){
        return false;
    }
    for(int i = n -1;i >index;--i){
        if(str[index] < str[i]){
            swap(str[index],str[i]);
            break;
        }
    }
    reverse(str.begin()+ index + 1,str.end());
    return true;
}

int main()
{
    int num = 1;
    string str;
    while(cin >> str){
        sort(str.begin(),str.end());
        do{
            cout <<str<<" "<<num<<endl;
            /* cout<<str<<endl; */
            num++;
        }while(GetNextPermutation(str));
        cout<<endl;
        num = 1;
    }
    return 0;
}

