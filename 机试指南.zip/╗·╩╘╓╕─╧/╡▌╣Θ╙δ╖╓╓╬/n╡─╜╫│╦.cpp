#include <iostream> 
#include <cstdio>

using namespace std;


int  Factorial_short(int n){
    if(n == 0){
        return 1;
    }else{
        return n*Factorial_short(n-1);
    }
}

long long Factorial(int n){
    if(n == 0){
        return 1;
    }else{
        return n*Factorial(n-1);
    }
}
unsigned long long Factorial_long(int n){
    if(n == 0){
        return 1;
    }else{
        return n*Factorial(n-1);
    }
}

int main()
{   
    int n;
    while(cin >>n){  
        cout <<n<<"的阶乘为:"<< Factorial_short(n)<<endl;//int最多求到12的阶乘，13！就越界，得错误的正数了
        cout <<n<<"的阶乘为:"<< Factorial(n)<<endl;//long long最多正常求到20的阶乘，21！就越界了,错误的正数
        cout <<n<<"的阶乘为:"<< Factorial_long(n)<<endl;//unsigned long long最多正常求到20的阶乘，21！就越界了，得错误的正数
    }
    return 0;
}

