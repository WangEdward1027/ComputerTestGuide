#include <iostream> 
#include <cstdio>

using namespace std;

int CountNodes(int m,int n){ //求m号结点下子树的结点总数，含结点自身
    if(m > n)  //递归出口
        return 0 ;
    else     //递归调用
        return 1 + CountNodes(m*2,n) + CountNodes(m*2+1,n);//根节点+左子树结点数+右子树结点数
}

int main()
{
    int m,n;
    while(scanf("%d%d",&m,&n) != EOF){
        cout<<CountNodes(m,n)<<endl;
    }
    return 0;
}
