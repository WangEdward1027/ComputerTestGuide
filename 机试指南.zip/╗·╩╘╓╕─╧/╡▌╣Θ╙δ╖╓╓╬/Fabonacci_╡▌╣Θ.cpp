#include <iostream> 
#include <cstdio>

using namespace std;

const int MAXN = 100;

int fibonacci[MAXN];

void Initial(){
    fibonacci[0] = 0;
    fibonacci[1] = 1;
    for(int i = 2;i < MAXN;++i){
        fibonacci[i] = fibonacci[i-1] + fibonacci[i-2];
    }
    return;
}

int main()
{
    Initial();
    int n;
    while(cin >> n){
         cout<<fibonacci[n]<<endl;
    }
    return 0;
}
