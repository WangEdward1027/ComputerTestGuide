#include <iostream> 
#include <cstdio>
#include <string>
#include <algorithm>

using namespace std;

int main()
{
    string str;
    while(cin>>str){
        sort(str.begin(),str.end());
        do{
            cout << str<<endl;
        }while(next_permutation(str.begin(),str.end()));//第三个参数，默认升序
        cout << endl;
    }
    return 0;
}

