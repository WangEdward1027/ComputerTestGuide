#include <iostream> 
#include <cstdio>

using namespace std;

int Fabonacci_1(int n){  //1.分治法:O(2^n)
    if(n == 0)
        return 0;
    else if(n == 1)
        return 1;
    else
        return Fabonacci_1(n-1) + Fabonacci_1(n-2);
}


int main()
{
       int n;
    while(cin >> n){
        cout<<Fabonacci_1(n)<<endl;
    }
    return 0;
}
