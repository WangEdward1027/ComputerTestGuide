#include <iostream> 
#include <cstdio>

using namespace std;


long long Hanoi(int n){   //递归函数
    if(n == 1){           //递归出口
        return 2;       
    }else{
        return 2*Hanoi(n-1)+1; //递归调用
    }
}

long long Hanoi_Middle(int n){
    if(n == 1){
        return 2;
    }else{
        return 3*Hanoi_Middle(n-1)+2;
    }
}

int main()
{
    int n;
    while(cin>>n){
    cout <<"允许不经过中间柱:" <<Hanoi(n)<<endl;
    cout <<"必须经过中间柱:"<<Hanoi_Middle(n)<<endl;
    }
    return 0;
}

