#include <iostream> 
#include <cstdio>
#include <string>
#include <algorithm>

using namespace std;

const int MAXN = 10;

bool visit[MAXN];
char sequence[MAXN];

//有点问题，因为会输出一样的排列,这个bug没改
void GetPermutation(string str,int index){
    if(index == str.size()){
        for(int i =0;i < str.size();++i){
            cout << sequence[i];
        }
        cout << endl;
    }
    for(int i =0;i<str.size();++i){
        if(visit[i]){
            continue;
        }
        visit[i] = true;
        sequence[index] = str[i];
        GetPermutation(str,index + 1);
        visit[i] = false;
    }
}

int main()
{
    string str;
    while(cin >> str){
        sort(str.begin(),str.end()); //头文件:#include <algorithm>
        cout<<"全排列有以下:"<<endl;
        GetPermutation(str,0);
        cout << endl;
    }
    return 0;
}

