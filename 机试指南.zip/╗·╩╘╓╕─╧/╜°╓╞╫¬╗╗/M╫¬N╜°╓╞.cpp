#include <iostream> 
#include <cstdio>
#include <string>
#include <vector>

using namespace std;
using std::cout;
using std::endl;

char InttoChar(long long num){ //数字转字符
    if(num < 10)
        return num+'0';
    else
        return num-10+'A';
}

long long ChartoInt(char target){ //字符转数字
    if(target >= '0' && target <= '9')
        return target-'0';
    else if('A' <= target && target <= 'Z')
        return target-'A'+10;
    else{
        perror("非法");
        return 0;
    }
}

void Convert_10toN(long long number,int n){
    vector<char> answer;
    while(number != 0){ //10进制转n进制
        answer.push_back(InttoChar(number % n));
        number /= n;
    }
    for(int i = answer.size()-1;i >= 0; --i){  //逆序输出vector里存的各位
        cout << answer[i];
    }
    cout <<endl;
}

long long Convert_Mto10(string str,int m){
    long long number = 0;
    int sz = str.size();
    for(int i =0;i < sz; ++i){
        number *= m;
        number += ChartoInt(str[i]);
    }
    /* cout <<"10进制：" <<number<<endl; */
    return number;
}

int main()
{
    int m,n;
    while(scanf("%d %d",&m,&n) != EOF){
        string str;
        cin >> str;
        long long number = Convert_Mto10(str,m);
        Convert_10toN(number,n);
    }
    return 0;
}
