#include <iostream>
#include <vector>

using namespace std;

void Convert10to8(int number,int n){
    vector<int> answer;
    while(number != 0){
        answer.push_back(number % n);
        number /= n;
    }
    for(int i = answer.size()-1; i >= 0; --i){
        cout << answer[i];
    }
    cout << endl;
}

int main(){
    int number;
    while(scanf("%d",&number) != EOF){
        Convert10to8(number,8);
    }    
    return 0;
}
