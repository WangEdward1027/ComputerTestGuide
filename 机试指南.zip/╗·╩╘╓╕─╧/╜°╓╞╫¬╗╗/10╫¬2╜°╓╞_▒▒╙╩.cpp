#include <iostream> 
#include <cstdio>
#include <vector>

using namespace std;
using std::cout;
using std::endl;

void Convert(unsigned int n){
    //1.转换函数，转为2进制
    vector<int> binary;//定义一个向量来接收二进制数
    while(n!= 0){
        binary.push_back(n%2);//从转换成二进制的最低位到最高位，存入vector
        n /= 2;
    }
    //2.倒序输出
    for(int i = binary.size()-1;i >= 0 ;--i){
        cout << binary[i];
    }
    cout <<endl;
    /* cout <<"进制数的位数为："<< binary.size()<<endl; */
}

int main()
{
    unsigned int n;
    while(scanf("%d", &n) != EOF){
        /* cout<<"转换为二进制数:"; */
        Convert(n);
    }
    return 0;
}

