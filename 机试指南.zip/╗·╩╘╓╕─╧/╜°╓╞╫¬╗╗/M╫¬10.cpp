#include <iostream> 
#include <cstdio>

using namespace std;
using std::cout;
using std::endl;

long long ChartoInt(char target){  //字符转数字
    if('0' <= target && target <= '9')  
        return target - '0'; //字符转数字， str[] - '0'  ||   ASCII码值相减
    else if('A' <= target && target <= 'Z')  
        return target - 'A' + 10; //'B'-'A'= 1,再+10，即B = 11
    else{
        perror("ERROR");
        return 0;    
    }
}

void ConvertMto10(string str, int m){
    long long number = 0;
    int sz = str.size();
    for(int i = 0;i < sz;++i){
        number *= m;
        number += ChartoInt(str[i]);
    }
    cout << number<<endl;  /* printf("%d",number); */
}

int main(){
    string str;
    while(cin >> str){
        /* str = str.substr(2); */  //去掉题干中的0x
        ConvertMto10(str,36);
    }
    return 0;
}
