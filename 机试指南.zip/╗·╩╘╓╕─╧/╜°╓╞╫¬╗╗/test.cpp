#include <iostream> 

using namespace std;
using std::cout;
using std::endl;

char InttoChar(int x){
    if(x<0)
        return x + '0';
    else 
        return x - 10 + 'a';
}


int main()
{
    int x = 16;
    
    return 0;
}

