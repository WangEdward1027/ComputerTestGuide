#include <iostream>
#include <cstdio>
#include <vector>

using namespace std;

char Int2Char(int target){//数字转字符：16进制，10=A,11=B,12=C,13=D,14=E,15=F,16=10
    if(target < 10)
        return target + '0';
    else 
        return target -10 +'A';
}

void Convert_10toN(int number,int n){
    vector<char> answer;
    while(number != 0){
        answer.push_back(Int2Char(number % n));
        number /= n;
    }
    for(int i=answer.size()-1;i >= 0;--i){  //倒序输出
        cout << answer[i];
    }
    cout << endl;
}

int main(){
    int number;
    /* while(cin>>number){ */
    while(scanf("%d",&number)){ /* while(scanf("%d",&number) != EOF){ */
        Convert_10toN(number,16);//n = 16进制
    }    
    return 0;
}
