#include <bits/stdc++.h>
#include <iostream> 
#include <cstdio>
#include <vector>
#include <string>

using namespace std;
using std::cout;
using std::endl;

int main()
{
    cout << "Hello world" << endl;
    return 0;
}

