#include <iostream> 
#include <cstdio>
#include <string>

using namespace std;
using std::cout;
using std::endl;

void len(string str){
    cout << str << endl;
    cout<<"string长度:"<<str.length()<<endl; //printf("%d\n",sz);
}

//3.1 像数组一样进行下标访问，下标从0到size()-1
void array(string str,int sz){
    sz = str.size();
    cout << "遍历字符串下标输出string:  ";
    for(int i = 0;i < sz;++i){
        cout << str[i]; //printf("%c",str[i]);
    }
    cout<<endl;//printf("\n");
    cout<<"访问下标，第7个元素:"<<str[6]<<endl;//printf("the 7th element of str is:%c\n",str[6]);
}

//3.2 迭代器访问
void iter(string str){
    cout << "迭代器输出string:  ";
    for(string::iterator it = str.begin();it != str.end(); ++it){
        cout<<*it;  /* printf("%c",*it); */
    }
    cout <<endl; /* printf("\n"); */

}

int main()
{
    //1.string的定义及初始化
    string str = "Hello World";
    int sz = str.size();
    //2.string的长度  || str.length()和str.size()基本相同
    len(str);
    //3.string的元素访问
    array(str,sz);
    iter(str);
    
    return 0;
}

